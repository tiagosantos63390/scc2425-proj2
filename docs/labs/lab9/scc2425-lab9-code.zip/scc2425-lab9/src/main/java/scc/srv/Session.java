package scc.srv;

public record Session(String uid, String user) {
}
